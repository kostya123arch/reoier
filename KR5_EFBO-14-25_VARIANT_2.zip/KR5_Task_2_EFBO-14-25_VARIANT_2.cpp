#include <iostream>
#include <stack>
#include <string>
using namespace std;

bool palindrom(string s) {
    stack<char> st;
    
    for (int i = 0; i < s.length(); i++) {
        st.push(s[i]);
    }
    
    for (int i = 0; i < s.length(); i++) {
        if (s[i] != st.top()) {
            return false;
        }
        st.pop();
    }
    
    return true;
}

int main() {
    string s;
    cin >> s;
    
    if (palindrom(s)) {
        cout << "YES";
    } else {
        cout << "NO";
    }
    
    return 0;
}